%
% Problem 11.12
%
clear
M = 50; % number of elements
spacing = 0.5; % element spacing in wavelengths
% The angles in degrees of the three spatially interference sources
phi_i1 = 5;
phi_i2 = 20;
phi_i3 = -30;
% The power levels of the signals and the noise
P_i1_db = 25; % power of interference source 1 (dB)
P_i2_db = 30; % power of interference source 2 (dB)
P_i3_db = 50; % power of interference source 3 (dB)
sigma_w = 1; % standard deviation of noise
% Compute the array response vectors of the three signals
v_i1 = exp(-j*2*pi*spacing*[0:(M-1)]'*sin(phi_i1*pi/180))/sqrt(M);
v_i2 = exp(-j*2*pi*spacing*[0:(M-1)]'*sin(phi_i2*pi/180))/sqrt(M);
v_i3 = exp(-j*2*pi*spacing*[0:(M-1)]'*sin(phi_i3*pi/180))/sqrt(M);
% Compute the covariance matrix of the interference-plus-noise
R_in = (10^(P_i1_db/10))*v_i1*v_i1' + (10^(P_i2_db/10))*v_i2*v_i2' + ...
(10^(P_i3_db/10))*v_i3*v_i3' + (sigma_w^2) * eye(M);
% Specify the signal of interest
phi_s = -1; % angle of signal of interest (deg)
SNR_db = 20; % signal-to-noise ratios (dB)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Part A
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the optimum beamformer to the desired angle
phi0 = 0; % angle to which we are steering (deg)
v0 = exp(-j*2*pi*spacing*[0:(M-1)]'*sin(phi0*pi/180))/sqrt(M);
% Diagonal loading levels
DLL_db = 0:30; % diagonal loading levels (dB)
% Loop on SNR to compute the signal mismatch losses
for n = 1:length(DLL_db)
v_s = exp(-j*2*pi*spacing*[0:(M-1)]'*sin(phi_s*pi/180))/sqrt(M);
x_s = (10^(SNR_db/20))*v_s; % actual array signal at SNR
x0 = (10^(SNR_db/20))*v0; % array signal at the steering angle
c_dl_unnorm = (R_in + (10^(DLL_db(n)/10))*eye(M))\v0;
c_dl = c_dl_unnorm/(c_dl_unnorm'*v0);
P_s(n) = abs(c_dl'*x_s)^2; % output power of actual signal
P0(n) = abs(c_dl'*x0)^2; % output power for signal at phi0
L_sm(n) = P_s(n)/P0(n); % mismatch loss
end
% Plot out the output powers versus diagonal loading level in decibels
figure
plot(DLL_db,10*log10(abs(P_s)),'b',...
DLL_db,10*log10(abs(P0)),'r--','linewidth',2.5);
xlabel('Diagonal Loading Level (dB)','fontweight','bold','fontsize',20);
ylabel('Output SNR (dB)','fontweight','bold','fontsize',20);
set(gca,'fontweight','bold','fontsize',18);
axis([0 30 -5 35]);
grid