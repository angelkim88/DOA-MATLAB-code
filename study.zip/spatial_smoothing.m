function R = spatial_smoothing(rx,p,bf)
%SPATIAL_SMOOTHING Summary of this function goes here
%   Detailed explanation goes here

if nargin <3, bf = 'b'; end
if nargin <2, p=size(rx,1)/2; end
[M,N]=size(rx);
K=M-p+1;
R=zeros(p,p);
bf=lower(bf(1));
for n=1:N
    Rf=zeros(p,);
    Rb=zeros(p,p);
    for k=0:K-1
        frx = rx(k+[1:p],n);
        Rf = Rf + frx*frx';
        if bf~='b'
            brx=conj(rx(M-k:-1:M-k-p+1,n));
            Rb = Rb + brx*brx';
        end
    end
    if bf=='f', R=R+Rf;
    else R=R+(Rf+Rb)/2;
    end
    
end

R = R/N/K;



