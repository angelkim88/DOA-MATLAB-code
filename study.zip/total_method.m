% Hanyang Univ. 
% 2013504773 KIm Jung Hwan

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Conventional beamforming
% Bartlett Pseudospectra for a M = 4 element array 
clear all

M=4;
sig2=.1;
theta=20;

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

S=[1];
R_hat=A*S*A'; % +sig2*eye(M);

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=real( (aw'*R_hat*aw)./M );   
end


figure;
plot(scan_theta*180/pi,10*log10(P/max(P)),'k','linewidth',1.5)
grid on
hold on
xlabel('Angle')
ylabel('|P(\theta)| (dB)')
axis([-90 90 -350 10])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Minimum Variance Algorithm
% Bartlett Pseudospectra for a M = 4 element array with noise variance = .1
clear all

M=4;
sig2=0.1;
theta=20;

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

S=[1];
R_hat=A*S*A'+sig2*eye(M);

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=real( M ./ (aw'*inv(R_hat)*aw) );   
end


%figure
plot(scan_theta*180/pi,10*log10(P/max(P)),'r.','linewidth',1.5)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% MUSIC Algorithm
% Bartlett Pseudospectra for a M = 6 element array
clear all

M=4;
sig2=0.1;
theta=20;
temp=eye(M);
D = 1;  % number of signals

u1=temp(:,1);

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

S=[1];
R_hat=A*S*A'%+sig2*eye(M);

[V,Dia]=eig(R_hat); 
[Y,Index]=sort(diag(Dia));   % sorts the eigenvalues from least to greatest
 EN=V(:,Index(1:M-D));      % calculate the noise subspace matrix of eigenvectors
                           % using the sorting done in the previous line

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=1/abs(aw'*EN*EN'*aw); 
end

plot(scan_theta*180/pi,10*log10(P/max(P)),'b-.','linewidth',1.5)
























