function phi_deg_estimates=DoA_ESPRIT(R,d_norm,tls)
if nargin<3, tls=0; end
M=size(R,1); 
[Vr,Lam]=eig(R);
[lambdas,idx]=sort(abs(diag(Lam)),'descend');
[dmax,L]=max(diff(-log10(lambdas+1e-3)));
Vs=Vr(:,idx(1:L));
V0=Vs(1:M/2,:); V1=Vs(M/2+1:end,:);
if tls==0
    [V,Lam]=eig([V0';V1']*[V0 V1]);
    [L_arranged,idx]=sort(abs(diag(Lam)),'descend');
    V12=V(1:L,L+1:end); V22=V(L+1:end,L+1:end);
    PSI=-V12*inv(V22);
else
    PSI=(V0'*V0)/V0'*V1;
end
exp_jGam=eig(PSI); Gam=angle(exp_jGam);
phi_deg_estimates=rad2deg(acos(Gam/(2*pi*d_norm)));











