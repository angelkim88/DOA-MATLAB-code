% Bartlett Pseudospectra for a M = 6 element array with noise variance = .1
clear all

M=6;
sig2=0.1;
theta=20;
temp=eye(M);
D = 1;  % number of signals

u1=temp(:,1);

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

S=[1];
R_hat=A*S*A'+sig2*eye(M);




%M�� ���׳���
%p�� �ΰ��� �� 

bf = 'b';
p=1;
[M,N] = size(R_hat);
K = M-p+1;
R = zeros(p,p);
bf = lower(bf(1));
for n=1:N
    Rf = zeros(p,p);
    Rb = zeros(p,p);
    for k=0:K-1
        frx = R_hat(k+[1:p],n);
        Rf = Rf + frx*frx';
        if bf ~= 'b'
            brx = conj(rx(M-k:-1:M-k-p+1,n));
            Rb = Rb +brx*brx';
        end
    end
    
    if bf =='f', R = R+Rf;
    else R = R+(Rf+Rb)/2;
    end
end
R_hat = R/N/K;










[V,Dia]=eig(R_hat) 
[Y,Index]=sort(diag(Dia))   % sorts the eigenvalues from least to greatest
 EN=V(:,Index(1:M-D))      % calculate the noise subspace matrix of eigenvectors
                           % using the sorting done in the previous line

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=1/abs(aw'*EN*EN'*aw); 
end


figure;
plot(scan_theta*180/pi,10*log10(P/max(P)),'k')
grid on
xlabel('Angle')
ylabel('|P(\theta)| (dB)')
axis([-90 90 -500 10])























% Bartlett Pseudospectra for a M = 6 element array with noise variance = .1
clear all

M=6;
sig2=0.1;
theta=20;
temp=eye(M);
D = 1;  % number of signals

u1=temp(:,1);

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

S=[1];
R_hat=A*S*A'+sig2*eye(M);

[V,Dia]=eig(R_hat) 
[Y,Index]=sort(diag(Dia))   % sorts the eigenvalues from least to greatest
 EN=V(:,Index(1:M-D))      % calculate the noise subspace matrix of eigenvectors
                           % using the sorting done in the previous line

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=1/abs(aw'*EN*EN'*aw); 
end


figure;
plot(scan_theta*180/pi,10*log10(P/max(P)),'k')
grid on
xlabel('Angle')
ylabel('|P(\theta)| (dB)')
axis([-90 90 -500 10])




















%M�� ���׳���
%p�� �ΰ��� �� 

bf = 'b';
[M,N] = size(rx);
K = M-p+1;
R = zeros(p,p);
bf = lower(bf(1));
for n=1:N
    Rf = zeros(p,p);
    Rb = zeros(p,p);
    for k=0:K-1
        frx = rx(k+[1:p],n);
        Rf = Rf + frx*frx';
        if bf ~= 'b'
            brx = conj(rx(M-k:-1:M-k-p+1,n));
            Rb = Rb +brx*brx';
        end
    end
    
    if bf =='f', R = R+Rf;
    else R = R+(Rf+Rb)/2;
    end
end
R = R/N/K;




















