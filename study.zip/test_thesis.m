clear all; close all;
Nfft=128; Ncp=Nfft/8; Nbps=2;
d_norm=0.5;
M=8; p=M-2;
SNRdb=5;
phs=[0:360]