% Hanyang Univ. 
% 2013504773 KIm Jung Hwan
% ESPRIT AOA estimation for a M = 4 element array with noise variance = .1
% use time averages instead of expected values by assuming ergodicity of the mean and 
% ergodicity of the correlation.
%  
% randn('state',0)
clear all

M=4;    % number of array elements
D = 1;  % number of signals
sig1=1; % signal amplitude
sig2=.1;    % noise variance
th1=-5*pi/180;      % angle of arrival 1


a1=[1];
for ii=2:M
     a1=[a1 exp(1j*(ii-1)*pi*sin(th1))];
end



A=[a1.'];          % calculate matrix of steering vectors for the D signals
S=[1];
R_hat=A*S*A'+sig2*eye(M);

[V,Dia]=eig(R_hat);            % find eigenvalues and eigenvectors of Rrr
[Y,Index]=sort(diag(Dia));   % sorts the eigenvalues from least to greatest
ES=V(:,Index(M-D+1:M));      % calculate the signal subspace matrix of eigenvectors
                              % using the sorting done in the previous line
          
E1=ES(1:M/2+1,:);           % construct the signal subspace form the first K rows of ES (K = M/2+1)
E2=ES(M/2:M,:);             % construct the signal subspace from the last K rows of ES
C=[E1';E2']*[E1 E2];
[EC,tmp]=eig(C);            %Perform the eigendecomposition on the matrix C
E12=EC(1,2);            % construct the E12 submatrix
E22=EC(2,2);            % construct the E22 submatrix
PSI=-E12*inv(E22);          % estimate PSI, the rotation operator
[Vp,Ep]=eig(PSI);           % find the eigenvalues and eigenvectors of rotation operator PSI
e=diag(Ep);

angs=asin(angle(e)/pi)*180/pi     % find the angles associated with the roots


for k=1:180;
    scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   a = [1];
    for jj=2:M
   a =[a exp(1j*(jj-1)*pi*sin(scan_theta(k)))];
   end
   a=a.';
  VN=eye(M)-A*Ep*A';          % construct the noise subspace which is perpindicular matrix of steering vectors
P1(k)=abs(1./(a'*VN*VN'*a)^2); 
P2(k)=abs((a'*A*Ep*A'*a)^2);
end
figure; 
plot(scan_theta*180/pi,log10(P1/max(P1)),'k',scan_theta*180/pi,log10(P2/max(P2)),'k:')      % plot pseudospectrum for ESPRIT
grid on
xlabel('Angle')
ylabel('|P(\theta)|')
axis([-90 90 -20 5])


