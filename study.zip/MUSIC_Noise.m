% Bartlett Pseudospectra for a M = 6 element array with noise variance = .1
clear all

M=6;
sig2=.1;
theta=20;
temp=eye(M);
D = 1;  % number of signals

u1=temp(:,1);

a1=[1];
for i=2:M
    a1=[a1 exp(j*(i-1)*pi*sin(theta*pi/180))];
end
A=[a1'];

K=100;          % K = length of time samples
s=sign(randn(1,K));      % calculate the K time samples of the signals for the 
                    % two arriving directions
                    
Rss=s*s'/K;      % source correlation matrix with uncorrelated signals
n=sqrt(sig2)*randn(M,K);     % calculate the K time samples of the noise for the 6 array
                            % elements
                    
Rnn=(n*n')/K;         % calculate the noise correlation matrix (which is no longer diagonal)
Rns=(n*s')/K;           % calculate the noise/signal correlation matrix
Rsn=(s*n')/K;           %  calculate the signal/noise correlation matrix
R_hat=(A*Rss*A')+(A*Rsn)+(Rns*A')+Rnn;        % combine all to get the array correlation matrix

[V,Dia]=eig(R_hat) 
[Y,Index]=sort(diag(Dia))   % sorts the eigenvalues from least to greatest
 EN=V(:,Index(1:M-D))      % calculate the noise subspace matrix of eigenvectors
                           % using the sorting done in the previous line

aw=[1];
for k=1:180;
   scan_theta(k)=(-90+k)*pi/180; % -90 ~ 90 
   clear a
aw=[1];
   for jj=2:M
      aw = [aw exp(j*(jj-1)*pi*sin(scan_theta(k)))];
   end
     aw=aw';
P(k)=1/abs(aw'*EN*EN'*aw); 
end


figure;
plot(scan_theta*180/pi,10*log10(P/max(P)),'k')
grid on
xlabel('Angle')
ylabel('|P(\theta)| (dB)')
axis([-90 90 -50 10])

